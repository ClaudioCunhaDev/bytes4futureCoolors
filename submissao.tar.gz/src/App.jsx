import "./App.css";
import { Coolors } from "./components/Coolors";

function App() {
  return (
    <div className="App">
      <Coolors />
    </div>
  );
}

export default App;
